module.exports = {
    "ATLASDB": "mongodb+srv://gustavo213098:tavitoperro@c1.3o2bb.mongodb.net/?retryWrites=true&w=majority&appName=c1"
}