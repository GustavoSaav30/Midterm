const About = () => {
    return <h1>Contact Me</h1>;
};

export default About;