const Projects = () => {
    return <h1>My Projects</h1>;
};

export default Projects;