const Footer = () => {
    return (
        <div>
            <br/>
            <br/>
            <br/>
            <footer>
                <p className="text-muted text-center">&copy;&nbsp;Copyright Julio Vinicius A. de Carvalho - COMP229 Web Application Development</p>
            </footer>
        </div>
    );
};

export default Footer;